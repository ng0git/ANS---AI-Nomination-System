import { useEffect, useRef } from "react";
import { useLocation } from "wouter";
import type { Candidate } from "@shared/schema";

// Import Chart.js
declare global {
  interface Window {
    Chart: any;
  }
}

interface StackedBarChartProps {
  candidates: Candidate[];
  scoreFilter: string;
  flagFilter: string;
}

export default function StackedBarChart({ candidates, scoreFilter, flagFilter }: StackedBarChartProps) {
  const [, setLocation] = useLocation();
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<any>(null);

  useEffect(() => {
    // Always destroy previous chart instance first
    if (chartInstance.current) {
      chartInstance.current.destroy();
      chartInstance.current = null;
    }

    // Load Chart.js if not already loaded
    if (!window.Chart) {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
      script.onload = () => {
        setTimeout(() => {
          createChart();
        }, 100);
      };
      document.head.appendChild(script);
    } else {
      setTimeout(() => {
        createChart();
      }, 50);
    }

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
        chartInstance.current = null;
      }
    };
  }, [candidates, scoreFilter, flagFilter]);

  const createChart = () => {
    if (!window.Chart || !chartRef.current) return;

    // Filter candidates based on current filters
    let filteredCandidates = candidates.filter(candidate => {
      // Score filter
      let matchesScore = true;
      if (scoreFilter !== "all") {
        const score = parseInt(candidate.score);
        if (!isNaN(score)) {
          switch (scoreFilter) {
            case "high":
              matchesScore = score >= 80;
              break;
            case "medium":
              matchesScore = score >= 50 && score < 80;
              break;
            case "low":
              matchesScore = score < 50;
              break;
          }
        } else {
          matchesScore = false;
        }
      }

      // Flag filter
      const matchesFlag = flagFilter === "all" || (candidate.flags && candidate.flags.includes(flagFilter));

      return matchesScore && matchesFlag && candidate.score !== "?";
    });

    // Sort by total score and take top 10
    const topCandidates = filteredCandidates
      .sort((a, b) => parseInt(b.score) - parseInt(a.score))
      .slice(0, 10);

    if (topCandidates.length === 0) {
      return;
    }

    const ctx = chartRef.current.getContext('2d');
    
    chartInstance.current = new window.Chart(ctx, {
      type: 'bar',
      data: {
        labels: topCandidates.map(c => c.name),
        datasets: [
          {
            label: 'Skills & Experience',
            data: topCandidates.map(c => c.scoreBreakdown.skills),
            backgroundColor: '#678D58',
            borderColor: '#678D58',
            borderWidth: 1,
            stack: 'stack1'
          },
          {
            label: 'Collaboration',
            data: topCandidates.map(c => c.scoreBreakdown.collaboration),
            backgroundColor: '#C9A76D',
            borderColor: '#C9A76D',
            borderWidth: 1,
            stack: 'stack1'
          },
          {
            label: 'Problem Solving',
            data: topCandidates.map(c => c.scoreBreakdown.problemSolving),
            backgroundColor: '#948979',
            borderColor: '#948979',
            borderWidth: 1,
            stack: 'stack1'
          },
          {
            label: 'Cultural Fit',
            data: topCandidates.map(c => c.scoreBreakdown.culturalFit),
            backgroundColor: '#7E5E9C',
            borderColor: '#7E5E9C',
            borderWidth: 1,
            stack: 'stack1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        onClick: (event: any, elements: any) => {
          if (elements.length > 0) {
            const candidateIndex = elements[0].index;
            const candidate = topCandidates[candidateIndex];
            setLocation(`/compare/${candidate.id}`);
          }
        },
        plugins: {
          legend: {
            position: 'bottom' as const,
            labels: {
              font: {
                family: 'Times New Roman',
                size: 12
              },
              color: '#222831',
              padding: 15
            }
          },
          tooltip: {
            callbacks: {
              title: function(context: any) {
                const candidateIndex = context[0].dataIndex;
                const candidate = topCandidates[candidateIndex];
                return `${candidate.name} (Total: ${candidate.score})`;
              },
              label: function(context: any) {
                return `${context.dataset.label}: ${context.parsed.y} points`;
              },
              footer: function(context: any) {
                return 'Click to compare with other candidates';
              }
            },
            backgroundColor: 'rgba(34, 40, 49, 0.9)',
            titleColor: '#DFD0B8',
            bodyColor: '#DFD0B8',
            footerColor: '#C9A76D',
            borderColor: '#948979',
            borderWidth: 1,
            cornerRadius: 8,
            padding: 12,
            titleFont: {
              family: 'Times New Roman',
              size: 13,
              weight: 'bold'
            },
            bodyFont: {
              family: 'Times New Roman',
              size: 11
            },
            footerFont: {
              family: 'Times New Roman',
              size: 10,
              style: 'italic'
            }
          }
        },
        scales: {
          x: {
            stacked: true,
            grid: {
              display: false
            },
            ticks: {
              font: {
                family: 'Times New Roman',
                size: 10
              },
              color: '#222831',
              maxRotation: 45
            }
          },
          y: {
            stacked: true,
            beginAtZero: true,
            max: 100,
            grid: {
              color: 'rgba(148, 137, 121, 0.2)'
            },
            ticks: {
              font: {
                family: 'Times New Roman',
                size: 11
              },
              color: '#222831'
            }
          }
        },
        onHover: (event: any, activeElements: any) => {
          if (chartRef.current) {
            chartRef.current.style.cursor = activeElements.length > 0 ? 'pointer' : 'default';
          }
        }
      }
    });
  };

  return (
    <div className="h-80 w-full">
      <canvas ref={chartRef}></canvas>
    </div>
  );
}